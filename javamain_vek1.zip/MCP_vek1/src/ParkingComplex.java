import uk.ac.aber.dcs.vehicles.*;

import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * Represents the parking complex which contains a number of zones
 *
 * @author vek1
 * @version 7th of May 2019
 */

public class ParkingComplex {
    private String name;

    private ArrayList<ParkingZone> zones;
    private ParkingZone zone1;
    private ParkingZone zone2;
    private ParkingZone zone3;
    private ParkingZone zone4;
    private ParkingZone zone5;


    private ArrayList<Attendant> attendants;


    private Scanner scan = new Scanner(System.in);

    /**
     * Constructor for the parking complex, creates zones
     */

    public ParkingComplex() throws IOException {
        name = "Moscow Vnukovo";

        zones = new ArrayList<>();
        zone1 = new ParkingZone("Zone 1", true);
        zone2 = new ParkingZone("Zone 2", true);
        zone3 = new ParkingZone("Zone 3", true);
        zone4 = new ParkingZone("Zone 4", false);
        zone5 = new ParkingZone("Zone 5", false);
        buildingParkingComplex();


        attendants = new ArrayList<>();

    }

    /**
     * This method gets the name of the Parking Complex
     *
     * @return name
     */

    public String getName() {
        return name;
    }

    /**
     * This method returns the current attendants pool
     *
     * @return attendants
     */
    public ArrayList<Attendant> getAttendants() {
        return attendants;
    }


    /**
     * This method sets the name of the complex
     *
     * @param name the new name
     */

    public void setName(String name) {
        this.name = name;
    }

    /**
     * This method sets the array list of attendant in the complex
     *
     * @param attendants list of attendants
     */

    public void setAttendants(ArrayList<Attendant> attendants) {
        this.attendants = attendants;
    }

    /**
     * Stores all the zones in the arrayList of zones
     */

    public void buildingParkingComplex() {

        zones.add(zone1);
        zones.add(zone2);
        zones.add(zone3);
        zones.add(zone4);
        zones.add(zone5);
    }

    public void addingNewZoneToTheParkingComplex(ParkingZone zone) {
        zones.add(zone);
    }

    /**
     * Method to park the vehicle in the zone. It stores the name of the Vehicle class in a String
     * and then, depending on which type of vehicle it is assigns it to the zone
     *
     * @param vehicle to get assigned to the zone
     */

    public void parkVehicleInTheZone(Vehicle vehicle) {
        String vehicleClass = vehicle.getClass().getName(); // stores the name of the vehicle class in a variable
        switch (vehicleClass) {
            case ("uk.ac.aber.dcs.vehicles.StandardSized"): // compares stored class to the options of switch case
                parkingStandardSizedVehicle(vehicle);
                break;
            case ("uk.ac.aber.dcs.vehicles.HigherSized"):
                System.out.print("Park your vehicle in Zone 1; ");
                zone1.addVehicleToTheSpace(vehicle, zone1.getParkingSpaces()); // calls the method to assign vehicle to the space in the right zone
                break;
            case ("uk.ac.aber.dcs.vehicles.LongerSized"):
                System.out.print("Park your vehicle in Zone 2; ");
                zone2.addVehicleToTheSpace(vehicle, zone2.getParkingSpaces());
                break;
            case ("uk.ac.aber.dcs.vehicles.Coach"):
                System.out.print("Park your vehicle in Zone 3; ");
                zone3.addVehicleToTheSpace(vehicle, zone3.getParkingSpaces());
                break;
            case ("uk.ac.aber.dcs.vehicles.Motorbike"):
                System.out.print("Park your vehicle in Zone 5; ");
                zone5.addVehicleToTheSpace(vehicle, zone5.getParkingSpaces());
                break;
            default:
                System.err.println("There is no zone to support this type of vehicle yet. Seek assistance!\n");

        }

    }

    /**
     * Method for parking the Standard sized vehicles
     *
     * @param vehicle to be parked
     */

    public void parkingStandardSizedVehicle(Vehicle vehicle) {
        System.out.println("Do you want to be parked outside? Y/N");
        String answer = scan.next().toUpperCase();

        if (answer.equals("Y")) {
            System.out.print("Park your vehicle in Zone 1; ");
            zone1.addVehicleToTheSpace(vehicle, zone1.getParkingSpaces());
        } else if (answer.equals("N")) {
            System.out.print("Park your vehicle in Zone 4; ");
            zone4.addVehicleToTheSpace(vehicle, zone1.getParkingSpaces());
        } else {
            System.err.println("Answer can not be processed, please try again.\n");
        }
    }

    /**
     * Method for manual attendant parking
     *
     * @param vehicle to be parked
     */
    public void attendantVehicleManualParking(Vehicle vehicle) {
        System.out.println("Input the ID number of the zone you want to park the vehicle in (e.g 1): \n");

        try {
            int answer = scan.nextInt();
            switch (answer) {
                case 1:
                    zone1.addVehicleToTheSpaceManually(vehicle, zone1.getParkingSpaces());
                    break;
                case 2:
                    zone2.addVehicleToTheSpaceManually(vehicle, zone2.getParkingSpaces());
                    break;
                case 3:
                    zone3.addVehicleToTheSpaceManually(vehicle, zone3.getParkingSpaces());
                    break;
                default:
                    System.err.println("Answer can not be processed, please try again.\n");

            }

        } catch (InputMismatchException e) {
            System.err.println("Please, input valid zone number. Thank you.");
            attendantVehicleManualParking(vehicle);
        }
    }

    /**
     * Method to activate an attendant
     *
     * @param name attendant to be activated
     */

    public void activateAttendant(String name) {
        for (Attendant a : attendants) {
            if (a.getName().equals(name)) {
                a.activateAttendant();
                System.out.println("Activated.");
            }
        }
    }

    /**
     * Method to deactivate an attendant
     *
     * @param name attendant to be activated
     */
    public void deactivateAttendant(String name) {
        for (Attendant a : attendants) {
            if (a.getName().equals(name)) {
                a.deactivateAttendant();
                System.out.println("Deactivated.");
            }
        }
    }

    /**
     * Method for activating all of the attendants in attendant pool
     */

    public void activateAllAttendants() {
        for (Attendant a : attendants) {
            a.activateAttendant();
        }
    }

    /**
     * Method for deactivation of all fo the attendants in the attendant pool
     */

    public void deactivateAllAttendants() {
        for (Attendant a : attendants) {
            a.deactivateAttendant();
        }
    }


    /**
     * Adds attendant to the attendant pool;
     * Checks whether its unique first
     *
     * @param attendant to be added
     * @return true if attendant wasnt in the pool and was added
     */

    public boolean addAttendant(Attendant attendant) {
        if (!attendants.contains(attendant)) {
            attendants.add(attendant);
            return true;
        }
        System.out.println("This attendant is already added.\n");
        return false;
    }

    /**
     * Removes attendant required, but first checks whether its available
     * in the first place
     *
     * @param attendantToBeRemoved the attendant to be removed
     * @return true if success
     */

    public void removeAttendant(String attendantToBeRemoved) {
        attendantToBeRemoved.toUpperCase(); // putting in the upper case to avoid errors related to the upper or lower case
        for (Attendant attendant : attendants) { // go through the pool of attendants
            if (attendant.getName().toUpperCase().equals(attendantToBeRemoved)) { // compare the passed name with the named in the pool
                attendants.remove(attendant);
                System.out.println("Attendant was removed.\n");
            } else {
                System.err.println("Cannot remove " + attendantToBeRemoved + // print error message otherwise
                        " - not accessible in the attendant pool.\n");
            }
        }
    }

        /**
         * Method to display information about attendants
         *
         * @return information unless there is no attendants available
         */

        public void displayAttendantsInformation () {
            if (attendants.size() != 0) {
                for (Attendant a : attendants) {
                    System.out.print("Attendant name: ");
                    System.out.print(a.getName() + ";");
                    System.out.print(" Active : ");
                    System.out.println(a.isActive() + ".\n");
                }
            } else if (attendants.size() == 0) {
                System.out.println("No attendants currently available.\n");
            }
        }

        /**
         * Method to print the general information about zones.
         */

        public void displayZoneInformation () {
            for (ParkingZone z : zones) {
                System.out.print("This is ");
                System.out.print(z.getName() + ".");
                System.out.print(" It has a capacity of " + z.getNumberOfSpaces() + " spaces.");

                if (z.isOutside()) {
                    System.out.println(" It is located outside the main building.\n");
                } else {
                    System.out.println(" It is located in the main building.\n");
                }

                displaySpaceInformation(z.getParkingSpaces());
            }
        }

        /**
         * Method to print the information about spaces and their availability
         *
         * @param spaces the spaces of the current zone
         */

        public void displaySpaceInformation (ParkingSpace[]spaces){
            for (ParkingSpace s : spaces) {
                System.out.print("Space ID " + s.getSpaceID() + " : ");

                if (s.isFree()) {
                    System.out.println("Available.\n");
                } else {
                    System.out.println("Unavailable.\n");
                }

            }
        }

        /**
         * Method to check all the zones of the complex for the collection code.
         *
         * @param code customer's collection code
         */
        public void searchForCode ( int code){
            for (ParkingZone z : zones) {
                z.lookingForTheVehicle(z.getCodes(), z.getParkingSpaces(), code, z.getHourlyRate());
            }
        }

        /** Method to load hourly rates from the file
         * @param filename to load rates from
         * @throws IOException
         */

        public void loadHourlyRates (String filename) throws IOException {

            FileReader fileInput = new FileReader(filename);
            Scanner infile = new Scanner(fileInput);
            infile.useDelimiter("\r?\n|\r");

            zone1.setHourlyRate(infile.nextDouble());
            zone4.setHourlyRate(infile.nextDouble());
            zone2.setHourlyRate(infile.nextDouble());
            zone3.setHourlyRate(infile.nextDouble());
            zone5.setHourlyRate(infile.nextDouble());

            infile.close();

        }

        /** Method to load attendants from the file
         * @param filename to load rates from
         * @throws IOException
         */

        public void loadAttendants (String filename) throws IOException {

            FileReader fileInput = new FileReader(filename);
            Scanner infile = new Scanner(fileInput);
            infile.useDelimiter("\r?\n|\r");

            attendants.clear();

            while (infile.hasNext()) {
                Attendant attendant = new Attendant();
                attendant.setName(infile.next());
                attendant.setIfActive(infile.nextBoolean());
                addAttendant(attendant);
            }

            infile.close();

        }

        /** Method to save the attendants to the file
         * @param filename to save info to
         * @throws IOException
         */

        public void saveAttendants (String filename) throws IOException {
            FileWriter fileOutput = new FileWriter(filename);
            PrintWriter outfile = new PrintWriter(fileOutput);


            for (Attendant a : attendants) {
                outfile.println(a.getName());
                outfile.println(a.isActive());
            }

            outfile.close();

        }


    }

