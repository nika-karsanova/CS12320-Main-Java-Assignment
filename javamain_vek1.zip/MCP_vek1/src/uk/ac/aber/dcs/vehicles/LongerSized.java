package uk.ac.aber.dcs.vehicles;

/**
 * Represents LongerSized vehicles such
 * as tall long wheel-based vans
 * @author vek1
 * @version 17th of April 2019
 */

public class LongerSized extends Vehicle {
    private String type = "longer sized vehicle";
    private double maxHeight = 2.9;
    private double minLength = 5.1;
    private double maxLength = 6;

    /**
     * Default constructor for the longer sized class
     */

    public LongerSized() {}


    /**
     * Constructor for the longer sized vehicles
     *
     * @param theLicense the number of the License plate
     */

    public LongerSized(String theLicense) {
        super(theLicense);
    }

    /**
     * Method to get the max height of the vehicle
     *
     * @return maxHeight
     */
    public double getMaxHeight(){
        return maxHeight;
    }

    /** Method to get the max Length of the vehicle
     *
     * @return maxLength
     */
    public double getMaxLength(){
        return maxLength;
    }

    /**
     * Method to get the min Heigth of the vehicle
     *
     * @return minHeight
     */
    public double getMinLength(){
        return minLength;
    }

    /**
     * Returns information about the longer sized vehicle
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This ");
        results.append(type);

        return results.toString() + super.toString();
    }
}


