package uk.ac.aber.dcs.vehicles;
import java.util.Scanner;

/**
 * This is a superclass of Vehicle,
 * which is used as a template for every other
 * type of vehicle
 * @author vek1, Veronika Karsanova
 * @version 17th of April 2019
 */

public class Vehicle {
    String licensePlate;


    /**
     * Default constructor for the Vehicle Class
     */

    public Vehicle() {}

    /**
     * Constructor for the Vehicle class,
     * which creates a Vehicle object
     * @param theLicense is the license plate number of the vehicle
     */

    public Vehicle(String theLicense){
        this.licensePlate = theLicense;
    }

    /**
     * Return the licensePlate number
     * @return licensePlate
     */
    public String getLicensePlate() {
        return licensePlate;
    }

    /**
     * Sets a new LicensePlate number
     * @param newLicense
     */

    public void setLicensePlate(String newLicense) {
        this.licensePlate = newLicense;
    }

    /**
     * Returns information about the Vehicle
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append(" has a license plate number of ");
        results.append(licensePlate);

        return results.toString();
    }


}