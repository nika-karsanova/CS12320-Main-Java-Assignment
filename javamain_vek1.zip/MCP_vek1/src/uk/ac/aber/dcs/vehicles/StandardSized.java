package uk.ac.aber.dcs.vehicles;

/**
 * Represents standardSized vehicles such
 * as cars and small vans
 * @author vek1
 * @version 17th of April 2019
 */

public class StandardSized extends Vehicle {
    private String type = "standard sized vehicle";
    private double maxHeight = 2;
    private double maxLength = 4.9;

    /**
     * Default constructor for the standard sized class
     */

    public StandardSized() {}


    /**
     * Constructor for the standard sized vehicles
     *
     * @param theLicense the number of the License plate
     */

    public StandardSized(String theLicense) {
        super(theLicense);
    }

    /**
     * Method to get the max height of the vehicle
     *
     * @return maxHeight
     */
    public double getMaxHeight(){
        return maxHeight;
    }

    /** Method to get the max Length of the vehicle
     *
     * @return maxLength
     */
    public double getMaxLength(){
        return maxLength;
    }

    /**
     * Returns information about the standard sized vehicle
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This ");
        results.append(type);

        return results.toString() + super.toString();
    }
}


