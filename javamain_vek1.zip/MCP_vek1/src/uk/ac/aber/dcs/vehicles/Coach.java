package uk.ac.aber.dcs.vehicles;

/**
 * Represents Coache which is one
 * of the possible Vehicle types
 * @author vek1
 * @version 17th of April 2019
 */

public class Coach extends Vehicle {
    private String type = "coach";
    private double maxLength = 15;


    /**
     * Default constructor for the coach class
     */

    public Coach() {}


    /**
     * Constructor for the coach
     *
     * @param theLicense the number of the License plate
     */

    public Coach(String theLicense) {
        super(theLicense);
    }

    /** Method to get the max Length of the vehicle
     *
     * @return maxLength
     */
    public double getMaxLength(){
        return maxLength;
    }

    /**
     * Returns information about the coach
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This ");
        results.append(type);

        return results.toString() + super.toString();
    }
}


