package uk.ac.aber.dcs.vehicles;

/**
 * Represents Motorbike which is one
 * of the possible Vehicle types
 * @author vek1
 * @version 17th of April 2019
 */

public class newVehicleType extends Vehicle {
    private String type;
    private int minHeight;
    private int minLength;
    private int maxHeight;
    private int maxLength;


    /**
     * Default constructor for the motorbike class
     */

    public newVehicleType() {}


    /**
     * Constructor for the new vehicle (e.g electrical car)
     *
     * @param theLicense the number of the License plate
     * @param theType the name of the new vehicle type
     * @param theMinHeight the minimal height of the new vehicle
     * @param theMinLength the minimal length of the new vehicle
     * @param theMaxHeight the maximal height of the new vehicle
     * @param theMaxLength the maximal length of the new vehicle
     */

    public newVehicleType(String theLicense, String theOwner, String theType, int theMinHeight, int theMinLength, int theMaxHeight, int theMaxLength) {
        super(theLicense);
        this.type = theType;
        this.minHeight = theMinHeight;
        this.minLength = theMinLength;
        this.maxHeight = theMaxHeight;
        this.maxLength = theMaxLength;

    }

    /**
     * Return the type of the Vehicle
     * @return type
     */

    public String getType() {
        return type;
    }

    /**
     * Return the minimum height of the Vehicle
     * @return minHeight
     */

    public int getMinHeight() {
        return minHeight;
    }

    /**
     * Return the minimum length of the Vehicle
     * @return minLength
     */

    public int getMinLength() {
        return minLength;
    }

    /**
     * Return the max Height of the vehicle
     * @return maxHeight
     */

    public int getMaxHeight() {
        return maxHeight;
    }

    /**
     * Return the max Length of the Vehicle
     * @return maxLength
     */

    public int getMaxLength() {
        return maxLength;
    }

    /**
     * Sets a new type name
     * @param newType
     */

    public void setType(String newType) {
        this.type = newType;
    }

    /**
     * Sets a new minimal height
     * @param newMinHeight
     */

    public void setMinHeight(int newMinHeight) {
        this.minHeight = newMinHeight;
    }

    /**
     * Sets a new minimal length
     * @param newMinWidth
     */

    public void setMinLength(int newMinWidth) {
        this.minLength = newMinWidth;
    }

    /**
     * Sets a new maximal height
     * @param newMaxHeight
     */

    public void setMaxHeight(int newMaxHeight) {
        this.maxHeight = newMaxHeight;
    }

    /**
     * Sets a new maximal length
     * @param newMaxLength
     */

    public void setMaxLength(int newMaxLength) {
        this.maxLength = newMaxLength;
    }

    /**
     * Returns information about the motorbike
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This new vehicle ");
        results.append(type);
        results.append(" has a minimum height of ");
        results.append(minHeight);
        results.append(" metres, a minimum length of ");
        results.append(minLength);
        results.append(" metres, a maximum height of ");
        results.append(maxHeight);
        results.append(" metres and a maximum length of ");
        results.append(maxLength);
        results.append(" metres. It ");

        return results.toString() + super.toString();
    }
}


