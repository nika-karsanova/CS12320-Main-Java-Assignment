package uk.ac.aber.dcs.vehicles;

/**
 * Represents Motorbike which is one
 * of the possible Vehicle types
 * @author vek1
 * @version 17th of April 2019
 */

public class Motorbike extends Vehicle {
    private String type = "motorbike";


    /**
     * Default constructor for the motorbike class
     */

    public Motorbike() {}


    /**
     * Constructor for the motorbike
     *
     * @param theLicense the number of the License plate
     */

    public Motorbike(String theLicense) {
        super(theLicense);
    }

    /**
     * Returns information about the motorbike
     * @return information for printing
     */

    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This ");
        results.append(type);

        return results.toString() + super.toString();
    }
}


