package uk.ac.aber.dcs.vehicles;

/**
 * Represents HigherSized vehicles such
 * as tall short wheel-based vans
 * @author vek1
 * @version 17th of April 2019
 */

public class HigherSized extends Vehicle {
    private String type = "higher sized vehicle";
    private double maxHeight = 2.9;
    private double maxLength = 4.9;
    private double minHeight = 2.1;


    /**
     * Default constructor for the higher sized class
     */

    public HigherSized() {}


    /**
     * Constructor for the higher sized vehicles
     *
     * @param theLicense the number of the License plate
     */

    public HigherSized(String theLicense) {
        super(theLicense);
    }

    /**
     * Method to get the max height of the vehicle
     *
     * @return maxHeight
     */
    public double getMaxHeight(){
        return maxHeight;
    }

    /** Method to get the max Length of the vehicle
     *
     * @return maxLength
     */
    public double getMaxLength(){
        return maxLength;
    }

    /**
     * Method to get the min Heigth of the vehicle
     *
     * @return minHeight
     */
    public double getMinHeight(){
        return minHeight;
    }

    /**
     * Returns information about the higher sized vehicle
     * @return information for printing
     */


    @Override
    public String toString() {

        StringBuilder results = new StringBuilder();
        results.append("This ");
        results.append(type);

        return results.toString() + super.toString();
    }
}


