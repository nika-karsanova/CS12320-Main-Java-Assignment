import uk.ac.aber.dcs.vehicles.*;

/**
 * Represents the spaces in zones and
 * if they are available
 * @author vek1
 * @version 7th of May 2019
 */

public class ParkingSpace {
    private int spaceID;
    private boolean isFree;
    private Vehicle vehicle;

    /** Default constructor for the class ParkingSpace
     * @param theID stores the space number of the slot
     */

    public ParkingSpace(int theID, boolean isFree) {
        this.spaceID = theID;
        this.isFree = isFree;

    }

    /**
     * Constructor for the parking space
     *
     * @param theID stores the space number of the slot
     * @param isFree stores the current state of the slot
     * @param theVehicle stores info about the vehicle
     */

    public ParkingSpace(int theID, boolean isFree, Vehicle theVehicle) {
        this.spaceID = theID;
        this.isFree = isFree;
        this.vehicle = theVehicle;

    }

    /**
     * Return the space ID number
     * @return spaceID
     */

    public int getSpaceID() {
        return spaceID;
    }

    /**
     * Return the weather the space is free or not
     * @return isFree
     */

    public boolean isFree() {
        return isFree;
    }

    /**
     * Return the vehicle info
     * @return vehicle
     */

    public Vehicle getVehicle() {
        return vehicle;
    }

    /**
     * Sets new space ID
     * @param newSpaceID
     */
    public void setSpaceID(int newSpaceID) {
        this.spaceID = newSpaceID;
    }

    /**
     * Sets the weather the space is free or not
     * @param isNowFree
     */

    public void setifFree (boolean isNowFree) {
        this.isFree = isNowFree;
    }

    /**
     * Sets the new vehicle to the spot
     * @param newVehicle
     */

    public void setVehicle(Vehicle newVehicle){
        this.vehicle = newVehicle;
    }

    /**
     * Assigns vehicle to the parking space
     * @param vehicle the vehicle being assigned to the spot
     */

    public void assignVehicle(Vehicle vehicle){
        this.vehicle = vehicle;
        isFree = false;
        System.out.println("space ID: " + spaceID + ".\n");
        System.out.println("Vehicle parked.\n");
    }

    /**
     * Removes any vehicle from the parking space
     */

    public void removeVehicle(){
        this.vehicle = null;
        isFree = true;
    }

}
