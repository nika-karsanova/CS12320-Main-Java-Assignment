import uk.ac.aber.dcs.vehicles.*;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Represents the zones of the parking building
 *
 * @author vek1
 * @version 7th of May 2019
 */

public class ParkingZone {

    private Scanner scan = new Scanner(System.in);

    private String name;
    boolean isOutside;

    private static final int NUMBER_OF_SPACES = 3;
    private ParkingSpace[] parkingSpaces;

    private Map<Integer, String> codes;
    private ArrayList<ParkingReceipt> receipts;

    private double hourlyRate;

    /**
     * Default constructor for the Parking Zone
     */

    public ParkingZone() {
        name = "";

        parkingSpaces = new ParkingSpace[NUMBER_OF_SPACES];
        populateWithParkingSpaces();

        codes = new HashMap<>();
        receipts = new ArrayList<>();

    }

    /**
     * Parking zone constructor.
     * Creates the zone with the given capacity.
     *
     * @param theName   is the name of the Zone (e.g. Zone 1)
     * @param isOutside stores whether or not the zone is outside
     */

    public ParkingZone(String theName, boolean isOutside) {
        this.name = theName;
        this.isOutside = isOutside;

        parkingSpaces = new ParkingSpace[NUMBER_OF_SPACES];
        populateWithParkingSpaces();

        codes = new HashMap<>();
        receipts = new ArrayList<>();

    }

    /**
     * Method that adds parking spaces to the zones
     */

    private void populateWithParkingSpaces() {
        for (int i = 0; i < NUMBER_OF_SPACES; i++) {
            int spaceID = i + 1;
            parkingSpaces[i] = new ParkingSpace(spaceID, true); // adds free parking spaces to the zone
        }
    }

    /**
     * This method returns the current active receipts of the complex
     *
     * @return attendants
     */

    public ArrayList<ParkingReceipt> getReceipts() {
        return receipts;
    }

    /**
     * Return the name of the Zone
     *
     * @return name
     */

    public String getName() {
        return name;
    }

    /**
     * Return the hourlyRate
     *
     * @return hourlyRate
     */

    public double getHourlyRate() {
        return hourlyRate;
    }

    /**
     * Return whether the parking zone is outside or not
     *
     * @return isOutside
     */

    public boolean isOutside() {
        return isOutside;
    }

    /**
     * Return the fixed number of spaces in the zone
     *
     * @return NUMBER_OF_SPACES
     */

    public static int getNumberOfSpaces() {
        return NUMBER_OF_SPACES;
    }

    /**
     * Returns the array of the zone
     *
     * @return parkingSpaces
     */

    public ParkingSpace[] getParkingSpaces() {
        return parkingSpaces;
    }

    /**
     * Sets the name of the zone
     *
     * @return name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the name of the zone
     *
     * @return name
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    /**
     * Set whether the zone is outside or not
     *
     * @return outside
     */

    public void setOutside(boolean outside) {
        isOutside = outside;
    }

    /**
     * Method to get the code map
     *
     * @return receipt vehicle pairs
     */

    public Map<Integer, String> getCodes() {
        return codes;
    }

    /**
     * Set receipt -  vehicle pairs
     *
     * @param codes
     */

    public void setCodes(Map<Integer, String> codes) {
        this.codes = codes;
    }

    /**
     * Method that adds vehicle to the space in zone and prints out the receipt
     *
     * @param vehicle the vehicle being assigned to the space
     * @param spaces  the spaces in zone
     */

    public boolean addVehicleToTheSpace(Vehicle vehicle, ParkingSpace[] spaces) {

        for (ParkingSpace s : spaces) { // goes through every space in the spaces array
            if (s.getSpaceID() <= NUMBER_OF_SPACES) { // if there is still space
                if (s.isFree()) { // and if it is free
                    s.assignVehicle(vehicle); // assigns vehicle to it
                    assigningReceiptToTheVehicle(vehicle);
                    return true;
                }
            }
        }
        System.out.println("THIS ZONE IS FULL, TRY AGAIN LATER.\n");
        return false;

    }

    /**
     * Method for attendants are roaming through the car park
     *
     * @param vehicle being parked
     * @param spaces  array of there chosen zone
     */

    public void addVehicleToTheSpaceManually(Vehicle vehicle, ParkingSpace[] spaces) {
        System.out.println("Input the ID of the space you want to park the vehicle in (e.g. 1): ");
        try {
            int space = scan.nextInt();
            int index = space - 1;
            ParkingSpace s = gettingTheParkingSpaceForManualParking(spaces, index);

            if (s.isFree()) {
                s.assignVehicle(vehicle);
                assigningReceiptToTheVehicle(vehicle);
            } else if (!s.isFree()) {
                System.err.println("Please choose a free space to park the vehicle. Thank you for cooperation.\n");
            }
        } catch (InputMismatchException e) {
            System.err.println("Please, input valid zone number. Thank you.");
            addVehicleToTheSpaceManually(vehicle, spaces);
        }
    }

    /**
     * Method the acceses the chosen space ID
     *
     * @param spaces array of spaces in the zone of attendants choice
     * @param index  the index of the chosen space id
     * @return parking space to assign vehicle to
     */

    public ParkingSpace gettingTheParkingSpaceForManualParking(ParkingSpace[] spaces, int index) {
        return spaces[index];
    }

    /**
     * Method for receipt generation
     *
     * @param vehicle being parked
     */

    public void assigningReceiptToTheVehicle(Vehicle vehicle) {

        ParkingReceipt p = new ParkingReceipt(); // receipt which will be assigned to the vehicle

        int code = p.generateCollectionCode(); // generating the random release code for the vehicle
        p.setCollectionCode(code);

        String time = p.formatTime(LocalDateTime.now()); // setting the time when vehicle arrived
        p.setTimeOfIssue(time);


        String license = vehicle.getLicensePlate();

        codes.put(code, license);
        receipts.add(p);

        System.out.println(p.toString());

    }

    /**
     * Method to collect the vehicle and free the space in the zone.
     *
     * @param codes  map of code - license plate values
     * @param spaces spaces of the zone
     * @param code   collection code for the vehicle
     */

    public void lookingForTheVehicle(Map<Integer, String> codes, ParkingSpace[] spaces, int code, double rate) {
        String license = codes.get(code);  // get the licences plate of the vehicle which owned passed released code

        for (ParkingSpace s : spaces) { // go through spaces in the zone
            if (s.getVehicle() != null) { // if the space has vehicle parked
                Vehicle vehicle = s.getVehicle(); // get the vehicle assigned to this place
                String which = vehicle.getLicensePlate(); // and get its license plate
                if (which.equals(license)) { // if license plates are equal
                    searchForReceipt(code, rate);
                    s.removeVehicle(); // remove the vehicle from the spot
                    System.out.println("Vehicle released.\n");
                    break; // leave the loop once done
                }

            }
        }

    }

    /**
     * Method to search for a receipt that has the collection code entered by the user
     *
     * @param code for collection inputer by the user
     */

    public void searchForReceipt(int code, double rate) {
        try {
            for (ParkingReceipt p : receipts) {
                if (p.getCollectionCode() == code) {
                    String time = p.formatTime(LocalDateTime.now()); // format time to look nice
                    p.setLeavingTime(time); // set leaving time
                    gettingTheTimeSpentInMCP(p, rate);

                }
            }
        } catch (InputMismatchException e) {
            System.err.println("Please, input valid code. Thank you.");
        }
    }

    /**
     * Method to get the difference in between time of arrival and collection
     *
     * @param receipt parking receipt from which the time of arrival and collection were taken
     */

    public void gettingTheTimeSpentInMCP(ParkingReceipt receipt, double rate) {
        String in = receipt.getTimeOfIssue();
        String out = receipt.getLeavingTime();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        LocalDateTime formatIn = LocalDateTime.parse(in, formatter); // converting the receipt time back
        LocalDateTime formatOut = LocalDateTime.parse(out, formatter);

        Duration difference = Duration.between(formatIn, formatOut); // finding difference
        calculatingTheTotal(difference, rate);
    }

    /**
     * Method that calculates the total that user needs to pay
     *
     * @param difference difference in between time of arrival and collection
     */
    public void calculatingTheTotal(Duration difference, double rate) {
        long seconds = Math.abs(difference.toSeconds()); // maths
        long hours = seconds / 3600;
        seconds -= (hours * 3600);
        long minutes = seconds / 60;
        seconds -= (minutes * 60);
        double total; // total that user needs to pay

        if (getDayOfTheWeek().equals(DayOfWeek.SUNDAY)) {
            System.out.println("Parking is free today!");
            long token = System.currentTimeMillis();
            exitingTheMCP(token);
        } else {
            if ((minutes > 0) || (seconds > 0)) { // if more than 1 sec passed – round up
                total = (hours + 1) * rate;
                disabledUser(total);
            } else if ((minutes == 0) || (seconds == 0)) {
                total = hours * rate;
                disabledUser(total);
            }
        }

    }

    /**
     * Asking the user whether or not they are disables
     *
     * @param total
     */
    public void disabledUser(double total) {
        System.out.println("Do you consider yourself a disabled user? Y/N");
        String answer = scan.next();
        if (answer.equals("Y")) {
            double halfTotal = total / 2;
            makingThePayment(halfTotal);
        } else if (answer.equals("N")) {
            makingThePayment(total);
        } else {
            System.out.println("Input valid answer");
            disabledUser(total);
        }
    }

    /**
     * Method to get the Day of the week
     *
     * @return day of the week
     */

    public DayOfWeek getDayOfTheWeek() {
        LocalDate today = LocalDate.now();
        DayOfWeek day = today.getDayOfWeek();
        return day;
    }

    /**
     * Method for user to make a payment
     *
     * @param total total amount for user to pay
     */

    public void makingThePayment(double total) {
        System.out.println("Please pay " + total + " units.");
        double pay = scan.nextDouble();

        if (pay < total) {
            System.out.println("The pay is less than the total, payment was not processed. Try again.\n");
            makingThePayment(total);
        } else if (pay == total) {
            System.out.println("Token was provided. You can now exit the car-park.\n");
            long token = System.currentTimeMillis();
            attendantCollect(token);
        } else if (pay > total) {
            double change = pay - total;
            System.out.println("You change is: " + change + " units.\n");
            System.out.println("Token was provided. You can now exit the car-park.\n");
            long token = System.currentTimeMillis(); // token issued
            attendantCollect(token);
        }

    }

    public void attendantCollect(long token) {
        System.out.println("Do you require attendant to collect the car for you? Y/N");
        String answer = scan.next();
        if (answer.equals("Y")) {
            System.out.println("Attendant, please collect the car.\n");
            exitingTheMCP(token);
        } else if (answer.equals("N")) {
            exitingTheMCP(token);
        } else {
            System.out.println("Input valid answer.");
            attendantCollect(token);
        }
    }


    /**
     * Method that offers user to input the token and leave the car park
     *
     * @param token given to the driver
     */
    public void exitingTheMCP(long token) {
        System.out.println("Exit Barrier. Do you wish to input the token? Y/N\n");
        String answer = scan.next();
        if (answer.equals("Y")) {
            long current = System.currentTimeMillis(); // token was used
            long takenTime = token - current;
            long minutes = takenTime / 60;

            if (minutes > 15) { // if the driver spent more than 15 minutes – seek assistance
                System.out.println("Token is invalid. Please, seek assistance.\n");
            } else if (minutes <= 15) {  // if less or 15 minutes – success
                System.out.println("Thank you for using MCP, Multi-Story Car Parking Program. Have a nice day!\n");
            }
        } else if (answer.equals("N")) {
            exitingTheMCP(token);
        }

    }

}

