import java.util.Objects;

/**
 * Represents the attendant in complex and
 * if they are available
 * @author vek1
 * @version 9th of May 2019
 */

public class Attendant {
    private String name;
    private boolean isActive;


    /** Defult constructor
     */

    public Attendant() {}

    /** Constructor for the attendant space
     *
     * @param theName attendant name
     * @param isActive wether attendant is active
     */

    public Attendant(String theName, boolean isActive) {
        this.name = theName;
        this.isActive = isActive;
    }

    /** Return the name of th attendant
     * @return name
     */

    public String getName(){
        return name;
    }

    /** Return whether active or not
     * @return isActive
     */

    public boolean isActive(){
        return isActive;
    }

    /** Sets name of the attendant
     * @param newName the name of the attendant
     */

    public void setName(String newName){
        this.name = newName;
    }

    /** Sets the active status the attendant
     * @param ifActive the status of the attendant
     */
    public void setIfActive(boolean ifActive) {
        this.isActive = ifActive;
    }

    /** Method to activate the Attendant
     */

    public void activateAttendant(){
        this.isActive = true;
    }

    /** Method to deactivate the attendant
     */

    public void deactivateAttendant(){
        this.isActive = false;
    }

    /** Method to check the uniqueness of attendants in the pool and activate
     * one particular attendant
     */

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Attendant a = (Attendant) o;
        return Objects.equals(name, a.name);
    }

}
