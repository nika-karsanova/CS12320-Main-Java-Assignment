import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import uk.ac.aber.dcs.vehicles.*;


/**
 * The main application class for the MCP. Has a command line menu.
 *
 * @author vek1
 * @version 7/05/2019
 */
public class SystemApp {
    private Scanner scan;
    private ParkingComplex complex;


    private SystemApp() throws IOException {
        scan = new Scanner(System.in);
        complex = new ParkingComplex();

        complex.loadHourlyRates("hourlyrate.txt");
        complex.loadAttendants("attendants.txt");

    }

    /**
     * User menu
     */

    private void runMenu() throws IOException {
        String response;
        do {
            printMenu();
            System.out.println("What would you like to do: \n");
            scan = new Scanner(System.in);
            response = scan.nextLine().toUpperCase();
            switch (response) {
                case "1":
                    registerCar(); // register vehicle's license plate and assigns it to the spot
                    break;
                case "2":
                    collectCar(); // collect car
                    break;
                case "3":
                    displayAll(); // display the car park information
                    break;
                case "4":
                    adminCheck(); // small security check before jumping to the admin options
                    break;
                case "Q":
                    break;
                default:
                    System.out.println("Something went wrong. Please, try again.\n");
            }
        } while (!(response.equals("Q")));
    }

    /**
     * Admin menu
     */

    private void runAdminMenu() throws IOException {
        String response;
        do {
            printAdminMenu();
            System.out.println("What would you like to do: \n");
            scan = new Scanner(System.in);
            response = scan.nextLine().toUpperCase();
            switch (response) {
                case "1":
                    displayAll(); // display the car park information
                    break;
                case "2":
                    addNewAttendant(); // admin: add attendant
                    break;
                case "3":
                    removeCurrentAttendant(); // admin: remove attendant
                    break;
                case "4":
                    createNewVehicleType(); // add a new Vehicle type
                    break;
                case "5":
                    createNewZoneForParkingComplex(); // add a new Zone
                    break;
                case "6":
                    complex.activateAllAttendants(); // make all of the attendants active
                    System.out.println("All attendants were activated.\n");
                    break;
                case "7":
                    complex.deactivateAllAttendants(); // deactivate all of the attendants
                    System.out.println("All attendants were deactivated.\n");
                    break;
                case "8":
                    complex.saveAttendants("attendants.txt");
                    break;
                case "9":
                    System.err.println("Sorry, this option was not yet implemented."); // load information from the file
                    break;
                case "10":
                    System.err.println("Sorry, this option was not yet implemented."); // save information to the file
                    break;
                case "11":
                    activateAnAttendant();
                    break;
                case "12":
                    deactivateAnAttendant();
                    break;
                case "Q":
                    break;
                default:
                    System.out.println("Something went wrong. Please, try again.\n");
            }
        } while (!(response.equals("Q")));
    }

    /**
     * Prints out the menu options for the user
     */

    private void printMenu() {
        System.out.println("1 - Register vehicle");
        System.out.println("2 - Collect vehicle");
        System.out.println("3 - Display the car park information");
        System.out.println("4 - Change to admin mode");
        System.out.println("q - Quit\n");
    }

    /**
     * Prints out the menu options for the admin
     */

    private void printAdminMenu() {
        System.out.println("1 - Admin: Display the car park information");
        System.out.println("2 - Admin: add attendant");
        System.out.println("3 – Admin: remove attendant");
        System.out.println("4 – Admin: add a new vehicle type");
        System.out.println("5 - Admin: add a new zone");
        System.out.println("6 – Admin: Activate all the attendants");
        System.out.println("7 – Admin: Deactivate all attendants");
        System.out.println("8 - Admin: Save the attendants to the file");
        System.out.println("9 - Admin: Load information from the file");
        System.out.println("10 – Admin: Save information to the file");
        System.out.println("11 - Admin: Activate required attendant");
        System.out.println("12 – Admin: Deactivate required attendant");
        System.out.println("q - Quit admin mode\n");
    }

    /**
     * Identifies the vehicle type
     */

    private void registerCar() {
        Vehicle vehicle;
        System.out.println("What type of vehicle is being registered?\n");
        System.out.println("1 – A car or a small van");
        System.out.println("2 – Tall wheel-based van");
        System.out.println("3 – Long wheel-based van");
        System.out.println("4 – Coach");
        System.out.println("5 – Motorbike");

        try {

            int type = scan.nextInt();
            switch (type) {
                case 1:
                    vehicle = new StandardSized();
                    requireAnAttendant(vehicle);
                    break;
                case 2:
                    vehicle = new HigherSized();
                    requireAnAttendant(vehicle);
                    break;
                case 3:
                    vehicle = new LongerSized();
                    requireAnAttendant(vehicle);
                    break;
                case 4:
                    vehicle = new Coach();
                    collectCommonInformation(vehicle);
                    complex.parkVehicleInTheZone(vehicle);
                    break;
                case 5:
                    vehicle = new Motorbike();
                    collectCommonInformation(vehicle);
                    complex.parkVehicleInTheZone(vehicle);
                    break;
                default:
                    System.err.println("This type of vehicle is not yet supported. Please, seek assistance!\n");
            }

        } catch (InputMismatchException e) {
            System.err.println("Please, choose one of the valid options. Thank you.\n");
        }
    }

    /**
     * Method to collect the registered car
     */

    private void collectCar() {
        System.out.println("Please, enter you collection code:\n");
        int code = scan.nextInt();
        complex.searchForCode(code);

    }

    /**
     * Method to create a new vehicle type
     */

    private void createNewVehicleType() {

        newVehicleType vehicle = new newVehicleType();

        System.out.println("Please enter the name fo the vehicle type (e.g. electric car): ");
        String type = scan.nextLine();

        System.out.println("Please enter the minimum height for the new vehicle type: ");
        int minHeight = scan.nextInt();

        System.out.println("Please enter the minimum length for the new vehicle type: ");
        int minLength = scan.nextInt();

        System.out.println("Please enter the maximum height for the new vehicle type: ");
        int maxHeight = scan.nextInt();

        System.out.println("Please enter the minimum length for the new vehicle type: ");
        int maxLength = scan.nextInt();

        vehicle.setType(type);
        vehicle.setMinHeight(minHeight);
        vehicle.setMinLength(minLength);
        vehicle.setMaxHeight(maxHeight);
        vehicle.setMaxLength(maxLength);

        System.out.println("New vehicle " + type + " was created. Thank you for using MCP, have a nice day!\n");

    }

    /**
     * Method to collect information which is common for every vehicle
     */

    private void collectCommonInformation(Vehicle vehicle) {

        System.out.println("Enter license plate number of the vehicle: ");
        String license = scan.next();
        vehicle.setLicensePlate(license);

    }

    /** Enables admin to activate particular attendant
     */

    private void activateAnAttendant(){
        System.out.println("Enter the name of the attendant you want to activate: \n");
        String name = scan.next();
        complex.activateAttendant(name);
    }

    /** Enables admin to deactivate particular attendant
     */

    private void deactivateAnAttendant(){
        System.out.println("Enter the name of the attendant you want to deactivate: \n");
        String name = scan.next();
        complex.deactivateAttendant(name);
    }

    /**
     * Method to check whether or not the attendant is required for vehicle parking
     *
     * @param vehicle being parked
     */

    private void requireAnAttendant(Vehicle vehicle) {
        System.out.println("Do you require an attendant? Y/N");

        String answer = scan.next().toUpperCase();
        if (answer.equals("N")) {
            collectCommonInformation(vehicle);
            complex.parkVehicleInTheZone(vehicle);
        } else if (answer.equals("Y")) {
            gettingAttendantForTheCustomer(vehicle);
        } else {
            System.err.println("Answer can not be processed, please try again.\n");
        }
    }

    /**
     * Removes active attendant from the pool of attendants for the customer
     * @param vehicle to be parked
     */
    private void gettingAttendantForTheCustomer(Vehicle vehicle) {
        ArrayList<Attendant> attendants = complex.getAttendants();
        if (attendants.size() != 0) { // 4
            // if there are attendants in the pool
            for (Attendant a : attendants) {
                if (a.isActive()) {
                    Random random = new Random();
                    Attendant current = attendants.get(random.nextInt(attendants.size())); // active attendants is called
                    attendants.remove(current); // active attendant is working with the customer
                    attendantCheck(vehicle); // they park the car
                    attendants.add(current); // and then they are returned back to the pool of free attendants
                    break;
                } else {
                    System.out.println("Non active attendant.");
                }
            }
        } else if (attendants.size() == 0) {
            System.out.println("No attendant currently available. Please, try later or continue to the self-car registration.\n");
        }
    }

    /**
     * A little security check. If person is a true attendant – they would know the code.
     *
     * @param vehicle being parked
     */

    private void attendantCheck(Vehicle vehicle) {
        System.out.println("Please enter password for further actions.\n");
        System.out.println("Hint for whoever is marking this: password is 'dontgettocloseitsdarkinside'");
        String password = scan.next();

        if (password.equals("dontgettocloseitsdarkinside")) {
            collectCommonInformation(vehicle);
            attendantManualParking(vehicle);
        } else {
            System.err.println("Incorrect password. Please try again or seek assistance.\n");
            attendantCheck(vehicle);
        }
    }

    /**
     * A little security check. If person is an admin – they would know the login and the password.
     */

    private void adminCheck() throws IOException  {
        System.out.println("Please enter your personal details for further actions.\n");
        System.out.println("Hint for whoever is marking this: login is 'admin'");
        System.out.println("Login: ");
        String login = scan.next();

        if (login.equals("admin")) {
            System.out.println("Password: ");
            System.out.println("Hint for whoever is marking that: password is 'itswheremydemonshide'");
            String password = scan.next();
            if (password.equals("itswheremydemonshide")) {
                runAdminMenu();
            } else {
                System.err.println("Incorrect password. Please try again or seek assistance.\n");
            }
        } else {
            System.err.println("Incorrect login. Please try again or seek assistance.\n");
        }
    }

    /**
     * Method for attendant's manual parking option
     *
     * @param vehicle being parked
     */
    private void attendantManualParking(Vehicle vehicle) {
        System.out.println("Do you want to choose parking spot manually? Y/N");

        String answer = scan.next().toUpperCase();
        if (answer.equals("N")) {
            complex.parkVehicleInTheZone(vehicle);
        } else if (answer.equals("Y")) {
            System.out.println("Please choose a zone and free space to park in from those listed below: \n");
            complex.displayZoneInformation();
            complex.attendantVehicleManualParking(vehicle);
        } else {
            System.err.println("Answer can not be processed, please try again.\n");
        }

    }

    /**
     * Method to add a new zone to the Parking Complex
     * note: incomplete
     */

    private void createNewZoneForParkingComplex() {
        ParkingZone zone = new ParkingZone();

        System.out.println("Please enter the name of the zone (e.g. Zone 1): ");
        String name = scan.nextLine();

        System.out.println("Is this zone outside of the main paring complex? Y/N: ");
        isTheNewZoneOutside(zone);

        zone.setName(name);
        complex.addingNewZoneToTheParkingComplex(zone);

        System.out.println("New zone " + name + " was created. Thank you for using MCP, have a nice day!\n");

    }

    /**
     * Method to set the indoor or outdoor placement of the new zone
     *
     * @param zone which is being created
     */

    private void isTheNewZoneOutside(ParkingZone zone) {
        String answer = scan.nextLine().toUpperCase();
        if (answer.equals("Y")) {
            zone.setOutside(true);
        } else if (answer.equals("N")) {
            zone.setOutside(false);
        } else {
            System.err.println("Answer can not be processed, please try again.\n");
        }
    }

    /**
     * Method to add a new attendant to the pool of attendants
     */

    private void addNewAttendant() {
        Attendant attendant = new Attendant();

        System.out.println("Enter the name of the attendant: ");
        String name = scan.nextLine();
        attendant.setName(name);

        System.out.println("Do you want to activate the attendant? Y/N");
        newAttendantActivation(attendant);

        complex.addAttendant(attendant);

        System.out.println("Attendant is added. Thank you for using MCP, have a nice day!\n");

    }

    /**
     * Method to remove attendant from attendant pool
     */

    private void removeCurrentAttendant() {
        System.out.println("Enter the name of the attendant to be removed.\n");
        String attendantToBeRemoved = scan.next();
        complex.removeAttendant(attendantToBeRemoved);
    }

    /**
     * Method for activation or deactivation of the new created
     * attendant
     *
     * @param attendant being created
     */

    private void newAttendantActivation(Attendant attendant) {
        String answer = scan.nextLine().toUpperCase();
        if (answer.equals("Y")) {
            attendant.activateAttendant();
        } else if (answer.equals("N")) {
            attendant.deactivateAttendant();
        }
    }

    /**
     * Method to display information about zones and their space availability
     * as well as attendants and wether or not they are active.
     */

    private void displayAll() {
        System.out.println("Here is the current complex information:\n");
        complex.displayAttendantsInformation();
        complex.displayZoneInformation();
    }

    /**
     * the Main method. It all starts here.
     */

    public static void main(String[] args) throws IOException {
        System.out.println("");
        System.out.println("*** WELCOME TO MCP, MULTI-STORY PARKING PROGRAM ***\n");

        SystemApp app = new SystemApp();
        app.runMenu();

        System.out.println("*** THANK YOU FOR USING MCP, HAVE A NICE DAY! ***");
    }

}