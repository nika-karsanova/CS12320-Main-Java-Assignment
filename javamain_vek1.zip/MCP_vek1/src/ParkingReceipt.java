import uk.ac.aber.dcs.vehicles.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Represent the Parking Receipt given to the driver
 *  @author vek1
 *  @version 9th of May 2019
 */

public class ParkingReceipt {
    private int collectionCode;
    private String issuedAt;
    private String leavingAt;

    /** Default constructor
     *
     */

    public ParkingReceipt() {}

    /** Constructor for Parking Receipt
     *
     * @param theCode the collection code
     * @param whenIssued time when the vehicle was registered
     * @param leavingAt when vehicle left
     */
    public ParkingReceipt(int theCode, String whenIssued, String leavingAt) {
        this.collectionCode = theCode;
        this.issuedAt = whenIssued;
        this.leavingAt = leavingAt;

    }

    /** Method to get the collection code of the receipt
     *
     * @return collectionCode of the receipt
     */

    public int getCollectionCode() {
        return collectionCode;
    }

    /** Method to get the time of issue for the receipt
     *
     * @return issuedAt time when receipt was issued
     */

    public String getTimeOfIssue() {
        return issuedAt;
    }

    /** Method to get the time of issue for the receipt
     *
     * @return leavingAt time when the the vehicle left
     */

    public String getLeavingTime() {
        return leavingAt;
    }

    /** Method to set the collection code of the receipt
     *
     * @param collectionCode of the receipt
     */
    public void setCollectionCode(int collectionCode){
        this.collectionCode = collectionCode;
    }

    /**
     * Method to set the time of issue
     * @param issuedAt setted time of issue
     */

    public void setTimeOfIssue(String issuedAt) { this.issuedAt = issuedAt; }

    /** Method to format Time of Issued and Leave
     *
     * @param currentTime
     * @return formatted time
     */

    public String formatTime(LocalDateTime currentTime){
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formatted = currentTime.format(format);
        return formatted;
    }

    /**
     * Method to set the time of leaving
     * @param leavingAt setted time of leaving
     */

    public void setLeavingTime(String leavingAt) {
        this.leavingAt = leavingAt;
    }


    /** Method to randomly generate the collection code
     *
     * @return randomly generated code
     */

    public int generateCollectionCode(){
        int code = (int)(Math.random() * 9000) + 1000;
        return code;
    }

    /** Returns information about the receipt
     *
     * @return info for printing
     */

    @Override
    public String toString() {
        StringBuilder results = new StringBuilder();
        results.append("*** RECEIPT ***\n");
        results.append("Code for collection: ");
        results.append(collectionCode);
        results.append("\n");
        results.append("Time of issue: ");
        results.append(issuedAt);
        results.append("\n");

        return results.toString();

    }

}
